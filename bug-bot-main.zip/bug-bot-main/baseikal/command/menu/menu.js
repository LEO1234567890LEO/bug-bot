const menu =  ` ●────────────●
       *A L L M E N U*
●────────────●
    〇 bugmenu

    〇 downoadmenu

    〇 groupmenu

    〇 ownermenu
●────────────●`
exports.menu = menu
