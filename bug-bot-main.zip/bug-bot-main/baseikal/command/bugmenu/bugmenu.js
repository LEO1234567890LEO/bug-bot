const bugmenu =  ` 
*Warning Bugs Are Very Dangerous*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*Bug Commands*
┏━━⊱
┣❏ᴋᴀʟ
┣❏ᴋᴀʟʙᴜɢ
┣❏ʜᴀɪᴋᴀʟ
┣❏ᴀᴘᴀ
┣❏ᴋᴇɴᴀᴘᴀ
┣❏ᴏᴋᴇ
┣❏ʙᴜɢ
┗━━⊱
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*ʙᴜɢ ᴇᴍᴏᴊɪ*
┏━━⊱
┣❏ʜᴀᴋᴏʟ (Amount)
┣❏ᴛʀᴏʟ (Amount)
┣❏ʜᴀᴛᴏʟ (Amount)
┣❏ᴛʀᴏʟɪ (Amount)
┣❏ᴘᴀʏᴍᴇɴᴛ (Amount)
┣❏ᴘᴀʏᴍᴇɴᴛ2 (Amount)
┣❏ᴘᴀʏᴍᴇɴᴛ3 (Amount)
┣❏ᴘᴀʏᴍᴇɴᴛ4 (Amount)
┣❏ᴘᴀʏᴍᴇɴᴛ5 (Amount)
┣❏ᴅᴀʀᴋɴᴇꜱ (Amount)
┣❏ᴅᴀʀᴋɴᴇꜱ2 (Amount)
┣❏ᴅᴀʀᴋɴᴇꜱ3 (Amount)
┣❏ᴅᴀʀᴋɴᴇꜱ4 (Amount)
┣❏ᴅᴀʀᴋɴᴇꜱ5 (Amount)
┣❏ʟᴏᴋᴀꜱɪ (Amount)
┣❏ʟᴏᴋᴀꜱɪ3 (Amount)
┣❏ʟᴏᴋᴀꜱɪ4 (Amount)
┣❏ʟᴏᴋᴀꜱɪ5 (Amount)
┣❏ᴘᴄ (Amount)
┣❏ᴘᴄ2 (Amount)
┣❏ᴘᴄ3 (Amount)
┣❏ᴘᴄ4 (Amount)
┣❏ᴘᴄ4 (Amount)
┣❏🔧 (Amount)
┣❏🪞 (Amount)
┣❏🛡️ (Amount)
┣❏🗡️ (Amount)
┣❏⚔️ (Amount)
┣❏🦖 (Amount)
┣❏🦕 (Amount)
┣❏👿 (Amount)
┣❏⚡ (Amount)
┣❏😈 (Amount)
┣❏⚔️ (Amount)
┣❏💥 (Amount)
┣❏🍂 (Amount)
┣❏🌪️ (Amount)
┣❏🔥 (Amount) 
┣❏🗿 (Amount)
┣❏🐕 (Amount)
┣❏🤣 (Amount)
┣❏😭 (Amount)
┣❏😂 (Amount)
┣❏🥵 (Amount)
┣❏🥶 (Amount)
┣❏😱 (Amount)
┣❏😎 (Amount)
┣❏🌷 (Amount)
┣❏🐲 (Amount)
┣❏🐉 (Amount)
┣❏🌵 (Amount) 
┣❏🎄 (Amount)
┣❏🌲 (Amount)
┣❏🌳 (Amount)
┣❏🌴 (Amount)
┣❏🌱 (Amount)
┣❏🌿 (Amount) 
┣❏☘️ (Amount)
┣❏🍀 (Amount)
┗━━⊱
[ ᴄᴏɴᴛᴏʜ 👿 ᴍᴀᴍᴘᴜꜱ ᴄʀᴀꜱʜ ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
[ ᴠɪʀᴛᴇxᴛ ᴅᴇʟᴀʏ ᴍᴀᴋᴇʀ ]
┏━━⊱
┣❏ᴠɪʀᴛᴇxᴛ1 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ2 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ3 (Amountʜɴʏᴀ)
┣❏ᴠɪʀᴛᴇxᴛ4 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ5 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ6 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ7 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ8 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ9 (Amount)
┣❏ᴠɪʀᴛᴇxᴛ10 (Amount)
┗━━⊱
*ꜱᴇɴᴅ ʙᴜɢ ᴛʀᴏʟɪ*
┏━━⊱
┣❏ɢᴏʏᴀɴɢ (947xx)
┣❏ʙᴜᴛᴛᴏɴ (947xxxx)
┣❏ꜱᴇɴᴅᴛʀᴏʟ (947xxxx)
┣❏ꜱᴇɴᴅᴛʀᴏʟ2 (947xxxx)
┣❏ꜱᴇɴᴅᴛʀᴏʟ3 (947xxxx)
┣❏ꜱᴇɴᴅᴛʀᴏʟ4 (947xxxx)
┣❏ꜱᴇɴᴅᴛʀᴏʟ5 (947xxxx)
┗━━⊱
[ OWNER 94764497078 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*ꜱᴇɴᴅ ʙᴜɢ ꜱᴀɴᴛᴇᴛ*
┏━━⊱
┣❏ꜱᴀɴᴛᴇᴛ (947xxxx)
┣❏ꜱᴀɴᴛᴇᴛ2 (947xxxx)
┣❏ꜱᴀɴᴛᴇᴛ3 (947xxxx)
┣❏ꜱᴀɴᴛᴇᴛ4 (947xxxx)
┣❏ꜱᴀɴᴛᴇᴛ5 (947xxxx)
┗━━⊱
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*ꜱᴇɴᴅ ʙᴜɢ ᴅᴏcᴜᴍᴇɴt*
┏━━⊱
┣❏ꜱᴇɴᴅᴅᴏᴄᴜ (947xxxx)
┣❏ꜱᴇɴᴅᴅᴏᴄᴜ2 (947xxxx)
┣❏ꜱᴇɴᴅᴅᴏᴄᴜ3 (947xxxx)
┣❏ꜱᴇɴᴅᴅᴏᴄᴜ4 (947xxxx)
┣❏ꜱᴇɴᴅᴅᴏᴄᴜ5 (947xxxx)
┗━━⊱
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*ꜱᴇɴᴅ ʙᴜɢ ʟᴏcation*
┏━━⊱
┣❏ꜱᴇɴᴅʟᴏᴋᴀꜱ (947xxxx)
┣❏ꜱᴇɴᴅʟᴏᴋᴀꜱ2 (947xxxx)
┣❏ꜱᴇɴᴅʟᴏᴋᴀꜱ3 (947xxxx)
┣❏ꜱᴇɴᴅʟᴏᴋᴀꜱ4 (947xxxx)
┣❏ꜱᴇɴᴅʟᴏᴋᴀꜱ5 (947xxxx)
┗━━
┣❏ᴊᴀᴅɪᴋᴀᴛᴀʟᴏɢ (Text)
┣❏ᴊᴀᴅɪᴛʀᴏʟɪ (Text)
┣❏ᴊᴀᴅɪʟᴏᴋᴀꜱ (Text)
┣❏ᴊᴀᴅɪᴅᴀʀᴋɴᴇꜱ (Text)
┣❏ᴊᴀᴅɪᴅᴏᴄᴜ (Text)
┣❏ᴊᴀᴅɪʙᴜɢɪɴᴠɪᴛᴇ (Text)
┣❏ᴊᴀᴅɪʙᴜɢᴘᴀʏᴍᴇɴᴛ (Text)
┣❏ᴊᴀᴅɪʙᴜɢꜱᴡ (Text)
┗━━⊱
[ Powered by *SANDARU-YT* ]`
exports.bugmenu = bugmenu
